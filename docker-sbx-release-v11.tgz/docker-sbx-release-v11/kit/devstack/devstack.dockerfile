# =============================================================================
# kit/devstack/devstack.dockerfile -- devstack workload image
#
# Companion recipe of devstack.yaml (same basename, same directory): the
# sandbox-kit frontend loads it after parsing the YAML descriptor.
# IMPORTANT: this is an ORDINARY Dockerfile. Do NOT put a
# '# syntax=docker/sandbox-kit:3' directive here -- that directive belongs
# ONLY on line 1 of devstack.yaml. If the recipe names the kit frontend, the
# build fails with: "content recipe ... names the kit frontend in its syntax
# directive; the recipe is an ordinary Dockerfile".
#
# Base (v11): the OFFICIAL pi kit image from docker/sbx-kits-contrib --
#   https://github.com/docker/sbx-kits-contrib/tree/main/pi
# sbx/pi-image = sbx/shell-docker-image (Docker engine inside) + pi
# (@earendil-works/pi-coding-agent, rebuilt nightly) + fd-find (pi's find
# tool; without it pi downloads a binary from GitHub at first use) + the
# official /usr/local/bin symlinks for minimal-PATH exec contexts. Node
# ships as in the base (22.x >= pi's 22.19 requirement) -- no nodesource
# layer anymore. This recipe only ADDS the devstack layer: openspec, herdr,
# jq/psql, vim/nano + the repo files (bootstrap, AGENTS.md, pi config).
# To pin the base (official convention: nightly builds roll 'latest'):
#   --build-arg BASE_IMAGE=docker.io/sbx/pi-image:<YYYYMMDD>-<sha>
# Docs: https://docs.docker.com/ai/sandboxes/customize/author/base-images
# =============================================================================

ARG BASE_IMAGE=docker.io/sbx/pi-image:latest
FROM ${BASE_IMAGE}

USER root

# Tooling on top of the official base: curl/gnupg (installers), jq (scripts),
# postgresql-client (psql for the agent), procps (pkill/pgrep in the
# bootstrap), vim-tiny + nano (editors for the human; vi -> vim.tiny).
# fd-find ships WITH the official base (pi's find tool) -- do not re-install.
RUN apt-get update \
 && apt-get install -y --no-install-recommends \
      ca-certificates curl gnupg jq postgresql-client procps vim-tiny nano \
 && rm -rf /var/lib/apt/lists/* \
 && if [ -e /usr/bin/vim.tiny ]; then ln -sf /usr/bin/vim.tiny /usr/local/bin/vi; fi

# Build-time gate: the official base must deliver a working pi (it is
# rebuilt nightly; a broken pull fails HERE, not at first `up`).
USER agent
RUN pi --version

# openspec (spec-driven development CLI) -- installed as `agent`, like pi in
# the official base: the global npm prefix there is owned by agent, so
# `pi install` and `pi update --self` keep working without EACCES.
USER agent
RUN npm install -g @fission-ai/openspec

# Official pattern: symlink npm-global binaries into /usr/local/bin (startup
# commands and some exec contexts run with a minimal PATH).
USER root
RUN ln -sf "$(npm prefix -g)/bin/openspec" /usr/local/bin/openspec

# herdr terminal multiplexer (agents drive it via its CLI and socket API).
# The upstream installer drops the binary under the INSTALLING user's home
# (root's $HOME/.local/bin during the build) -- invisible to `agent`, which
# is why `herdr: command not found` appeared while the build passed. Install,
# then RELOCATE to /usr/local/bin and verify: a missing binary FAILS the
# build instead of surfacing at runtime.
RUN set -e; \
    curl -fsSL https://releases.herdr.dev/app/install.sh -o /tmp/herdr-install.sh; \
    sh /tmp/herdr-install.sh; \
    _h="$(command -v herdr 2>/dev/null || find /root /usr/local /opt -maxdepth 4 -type f -name herdr 2>/dev/null | head -n 1)"; \
    [ -n "$_h" ] || { echo 'herdr binary not found after install -- see releases.herdr.dev' >&2; exit 1; }; \
    install -m 0755 "$_h" /usr/local/bin/herdr; \
    rm -f /tmp/herdr-install.sh; \
    /usr/local/bin/herdr --version || /usr/local/bin/herdr version || true

# -- Repo-provided files (AGENTS.md, env loader, pi model template, bootstrap) -
COPY --chown=agent:agent files/ /home/agent/

RUN chmod +x /home/agent/bootstrap/*.sh \
 && mkdir -p /home/agent/.pi/agent /home/agent/workspaces/logs \
 && echo '[ -f /home/agent/.devstack_env ] && . /home/agent/.devstack_env' \
      >> /home/agent/.bashrc \
 && chown -R agent:agent /home/agent

# BASH_ENV makes the devstack exports available to non-interactive
# `bash -c` calls (what `sbx exec` runs); ~/.bashrc covers interactive shells.
ENV BASH_ENV=/home/agent/.devstack_env

# Labels (official kit pattern): re-declare start-docker (Docker engine
# inside the sandbox), override the flavor so sbx reports THIS kit's name,
# record the official base.
LABEL com.docker.sandboxes.start-docker="true" \
      com.docker.sandboxes.flavor="devstack" \
      com.docker.sandboxes.base="sbx/pi-image"

USER agent
ENTRYPOINT ["bash"]
CMD []
